

<?php $__env->startSection('styles'); ?>
    <style>
        .dropdown-search-wrapper .suggestions-box {
            max-height: 200px;
            overflow-y: auto;
        }

        .dropdown-search-wrapper .suggestion-item {
            padding: 8px 12px;
        }

        .dropdown-search-wrapper .suggestion-item:hover {
            background-color: #f1f1f1;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Update account details</h1>
            <p class="text-muted">Ensure your account is using a long, random password to stay secure.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Recruiter Profile</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('recruiters.update')); ?>" enctype="multipart/form-data"
                        class="bg-white shadow-md rounded-2xl p-8 max-w-3xl mx-auto">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Name <span class="text-danger">*</span></label>
                            <div class="col-sm-4">
                                <input type="text" name="name" value="<?php echo e(old('name', $recruiter->name ?? '')); ?>"
                                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Category <span class="text-danger">*</span></label>
                            <div class="col-sm-4">
                                <div class="dropdown-search-wrapper" style="position: relative; align-items: center; width: 100%;">
                                    <input type="text" id="categoryInput" class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category"
                                        placeholder="Search category..." autocomplete="off" value="<?php echo e(old('category', $recruiter->category->name ?? '')); ?>"
                                        >
                                    <input type="hidden" name="category_id" id="categoryIdInput" value="<?php echo e(old('category_id', $recruiter->category_id ?? '')); ?>">
                                    <div id="categorySuggestionBox" class="suggestions-box"
                                        style="display: none; position: absolute; top: 100%; left: 0; right: 0; z-index: 1000; background: #fff; border: 1px solid #ccc;">
                                    </div>
                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row mb-3 d-none">
                            <label class="col-sm-2 col-form-label">Location <span class="text-danger">*</span></label>
                            <div class="col-sm-4">
                                <select name="location_id"
                                    class="form-select location_select select2 <?php $__errorArgs = ['location_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select Location</option>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($loc->id); ?>"
                                            <?php echo e((old('location_id', $recruiter->location_id ?? '') == $loc->id || strtolower(trim($loc->name)) == 'usa') ? 'selected' : ''); ?>>
                                            <?php echo e($loc->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['location_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">State</label>
                            <div class="col-sm-4">
                                <div class="dropdown-search-wrapper" style="position: relative; align-items: center; width: 100%;">
                                    <input type="text" id="stateInput" class="form-control <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="state"
                                        placeholder="Search state..." autocomplete="off" value="<?php echo e(old('state', $recruiter->state->name ?? '')); ?>"
                                        >
                                    <input type="hidden" name="state_id" id="stateIdInput" value="<?php echo e(old('state_id', $recruiter->state_id ?? '')); ?>">
                                    <div id="stateSuggestionBox" class="suggestions-box"
                                        style="display: none; position: absolute; top: 100%; left: 0; right: 0; z-index: 1000; background: #fff; border: 1px solid #ccc;">
                                    </div>
                                    <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">City</label>
                            <div class="col-sm-4">
                                <div class="dropdown-search-wrapper" style="position: relative; align-items: center; width: 100%;">
                                    <input type="text" id="cityInput" class="form-control <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city"
                                        placeholder="Search city..." autocomplete="off" value="<?php echo e(old('city', $recruiter->city->name ?? '')); ?>"
                                        >
                                    <input type="hidden" name="city_id" id="cityIdInput" value="<?php echo e(old('city_id', $recruiter->city_id ?? '')); ?>">
                                    <div id="citySuggestionBox" class="suggestions-box"
                                        style="display: none; position: absolute; top: 100%; left: 0; right: 0; z-index: 1000; background: #fff; border: 1px solid #ccc;">
                                    </div>
                                    <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        
                        

                        
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Logo</label>
                            <div class="col-sm-4">
                                <input type="file" name="logo" id="logo_file" accept="image/*"
                                    class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <div class="d-flex">
                                    
                                    <div id="logo_preview" class="mt-2" style="display: none; margin-right: 10px;">
                                        <img id="logo_preview_img" src="#" alt="Logo Preview" width="100" height="100" class="rounded border">
                                    </div>

                                    
                                    <?php if(!empty($recruiter->logo)): ?>
                                        <div class="mt-2">
                                            <img src="<?php echo e(asset('storage/' . $recruiter->logo)); ?>" width="100" height="100" class="rounded border">
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Color Scheme</label>
                            <div class="col-sm-4">
                                <input type="color" name="color" id="color"
                                    class="form-control form-control-color <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('color', $recruiter->color ?? '#ffffff')); ?>">
                                <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted">Choose your preferred color scheme</small>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Slogan</label>
                            <div class="col-sm-4">
                                <input type="text" name="slogan" id="slogan"
                                    class="form-control <?php $__errorArgs = ['slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('slogan', $recruiter->slogan ?? '')); ?>"
                                    placeholder="Enter your slogan...">
                                <?php $__errorArgs = ['slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted">Add a short catchy line about your brand</small>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Info</label>
                            <div class="col-sm-10">
                                <textarea name="info" id="info" rows="3"
                                    class="form-control <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Enter company information or description..."><?php echo e(old('info', $recruiter->info ?? '')); ?></textarea>
                                <?php $__errorArgs = ['info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="text-muted">Provide additional details about your organization</small>
                            </div>
                        </div>

                        <div class="text-end mt-4">
                            <button type="submit" class="btn btn-sm btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-lg-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Update Password</h6>
                </div>
                <div class="card-body">
                    <form id="passwordForm" method="POST" action="<?php echo e(route('password.update')); ?>"
                        class="bg-white shadow-md rounded-2xl p-8 max-w-3xl mx-auto mt-10">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row mb-3">
                            <label for="password" class="col-sm-2 col-form-label">
                                New Password <span class="text-danger">*</span>
                            </label>
                            <div class="col-sm-3">
                                <input type="password" id="password" name="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter new password...">
                                
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password_confirmation" class="col-sm-2 col-form-label">
                                Confirm Password <span class="text-danger">*</span>
                            </label>
                            <div class="col-sm-3">
                                <input type="password" id="password_confirmation" name="password_confirmation"
                                    class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter confirm password...">
                                
                            </div>
                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-sm btn-primary">
                                Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script type="text/javascript">
        const categoryOptions = <?php echo json_encode($categoryOptions, 15, 512) ?>;
        const categoryInput = document.getElementById("categoryInput");
        const categoryIdInput = document.getElementById("categoryIdInput");
        const categorySuggestionBox = document.getElementById("categorySuggestionBox");

        categoryInput.addEventListener("input", function() {
            const query = this.value.toLowerCase().trim();
            categorySuggestionBox.innerHTML = "";
            categoryIdInput.value = "";
            $(categoryInput).removeClass('is-invalid');
            $(categoryInput).find('.invalid-feedback').remove();

            if (!query) {
                categorySuggestionBox.style.display = "none";
                return;
            }

            // Filter results
            const filtered = Object.entries(categoryOptions).filter(([key, value]) =>
                value.toLowerCase().includes(query)
            );

            if (filtered.length === 0) {
                categorySuggestionBox.style.display = "none";
                return;
            }

            // Show suggestions
            filtered.forEach(([key, value]) => {
                const div = document.createElement("div");
                div.classList.add("suggestion-item");
                div.textContent = value;
                div.style.cursor = "pointer";
                div.onclick = function() {
                    categoryInput.value = value;
                    categoryIdInput.value = key;
                    categorySuggestionBox.style.display = "none";
                };
                categorySuggestionBox.appendChild(div);
            });

            categorySuggestionBox.style.display = "block";
        });

        const stateOptions = <?php echo json_encode($stateOptions, 15, 512) ?>; // [{id, name}]
        const cityOptions = <?php echo json_encode($citiyOptions, 15, 512) ?>; // [{id, state_id, name}]

        const stateInput = document.getElementById("stateInput");
        const stateIdInput = document.getElementById("stateIdInput");
        const stateSuggestionBox = document.getElementById("stateSuggestionBox");

        const cityInput = document.getElementById("cityInput");
        const cityIdInput = document.getElementById("cityIdInput");
        const citySuggestionBox = document.getElementById("citySuggestionBox");

        // ---------- Utility function ----------
        function createSuggestionBox(input, hiddenInput, suggestionBox, items, onSelect) {
            suggestionBox.innerHTML = "";
            const query = input.value.toLowerCase().trim();

            if (!query) {
                suggestionBox.style.display = "none";
                return;
            }

            const filtered = items.filter(item => item.name.toLowerCase().includes(query));
            if (filtered.length === 0) {
                suggestionBox.style.display = "none";
                return;
            }

            filtered.forEach(item => {
                const div = document.createElement("div");
                div.classList.add("suggestion-item");
                div.textContent = item.name;
                div.style.cursor = "pointer";
                div.onclick = function() {
                    input.value = item.name;
                    hiddenInput.value = item.id;
                    suggestionBox.style.display = "none";
                    if (onSelect) onSelect(item);
                };
                suggestionBox.appendChild(div);
            });

            suggestionBox.style.display = "block";
        }

        // ---------- STATE AUTOCOMPLETE ----------
        stateInput.addEventListener("input", function() {
            stateIdInput.value = "";
            $(stateInput).removeClass('is-invalid');
            $(stateInput).siblings('.invalid-feedback').remove();

            createSuggestionBox(
                stateInput,
                stateIdInput,
                stateSuggestionBox,
                stateOptions,
                (selectedState) => {
                    // Clear city if state changes
                    cityInput.value = "";
                    cityIdInput.value = "";
                }
            );
        });

        // ---------- CITY AUTOCOMPLETE ----------
        cityInput.addEventListener("input", function() {
            cityIdInput.value = "";
            $(cityInput).removeClass('is-invalid');
            $(cityInput).siblings('.invalid-feedback').remove();

            // If a state is selected, filter cities within that state
            let filteredCities = cityOptions;
            const selectedStateId = stateIdInput.value;
            if (selectedStateId) {
                filteredCities = cityOptions.filter(city => city.state_id == selectedStateId);
            }

            createSuggestionBox(
                cityInput,
                cityIdInput,
                citySuggestionBox,
                filteredCities,
                (selectedCity) => {
                    // Auto-fill state if user selects city first
                    const foundState = stateOptions.find(s => s.id === selectedCity.state_id);
                    if (foundState) {
                        stateInput.value = foundState.name;
                        stateIdInput.value = foundState.id;
                    }
                }
            );
        });

        // Hide suggestions on outside click
        document.addEventListener("click", (e) => {
            if (!document.querySelector(".dropdown-search-wrapper").contains(e.target)) {
                categorySuggestionBox.style.display = "none";
                stateSuggestionBox.style.display = "none";
                citySuggestionBox.style.display = "none";
            }
        });

        // Clear input if user didn't select a suggestion
        categoryInput.addEventListener("blur", function() {
            setTimeout(() => {
                if (!categoryIdInput.value) {
                    categoryInput.value = "";
                }
                categorySuggestionBox.style.display = "none";
            }, 200);
        });

        stateInput.addEventListener("blur", function() {
            setTimeout(() => {
                if (!stateIdInput.value) {
                    stateInput.value = "";
                }
                stateSuggestionBox.style.display = "none";
            }, 200);
        });

        cityInput.addEventListener("blur", function() {
            setTimeout(() => {
                if (!cityIdInput.value) {
                    cityInput.value = "";
                }
                citySuggestionBox.style.display = "none";
            }, 200);
        });

        document.addEventListener('DOMContentLoaded', function() {
            const input = document.getElementById('logo_file');
            const previewDiv = document.getElementById('logo_preview');
            const img = document.getElementById('logo_preview_img');

            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(evt) {
                        img.src = evt.target.result;
                        previewDiv.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                } else {
                    previewDiv.style.display = 'none';
                }
            });

            const stars = document.querySelectorAll(".star-rating i");
            const ratingInput = document.getElementById("rating");

            stars.forEach(star => {
                star.addEventListener("click", function() {
                    const value = this.getAttribute("data-value");
                    ratingInput.value = value;

                    stars.forEach(s => {
                        if (s.getAttribute("data-value") <= value) {
                            s.classList.remove("far");
                            s.classList.add("fas");
                        } else {
                            s.classList.remove("fas");
                            s.classList.add("far");
                        }
                    });
                });
            });
        });
    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/techsavy/public_html/listofrecruiters.com/resources/views/profile/edit.blade.php ENDPATH**/ ?>