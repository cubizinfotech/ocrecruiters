<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination" class="flex justify-left items-center space-x-2 mt-6">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200 text-gray-400 cursor-not-allowed">
                <img src="<?php echo e(asset('img/page-prev.svg')); ?>" alt="Previous" class="w-20 h-20 object-contain opacity-50" />
            </span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="flex items-center justify-center w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 hover:bg-indigo-200">
                <img src="<?php echo e(asset('img/page-prev.svg')); ?>" alt="Previous" class="w-20 h-20 object-contain" />
            </a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="px-3 py-1 text-gray-500"><?php echo e($element); ?></span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="flex items-center justify-center w-10 h-10 rounded-full bg-indigo-100 text-indigo-800 font-bold"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" class="flex items-center justify-center w-10 h-10 rounded-full text-gray-500 hover:bg-indigo-50 hover:text-indigo-700">
                            <?php echo e($page); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="flex items-center justify-center w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 hover:bg-indigo-200">
                <img src="<?php echo e(asset('img/page-next.svg')); ?>" alt="Next" class="w-20 h-20 object-contain opacity-50" />
            </a>
        <?php else: ?>
            <span class="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200 text-gray-400 cursor-not-allowed">
                <img src="<?php echo e(asset('img/page-next.svg')); ?>" alt="Next" class="w-20 h-20 object-contain" />
            </span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH /home/techsavy/public_html/listofrecruiters.com/resources/views/vendor/pagination/custom-tailwind.blade.php ENDPATH**/ ?>