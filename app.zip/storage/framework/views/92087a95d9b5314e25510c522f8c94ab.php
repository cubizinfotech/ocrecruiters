<?php echo e($slot); ?>

<?php /**PATH /home/techsavy/public_html/listofrecruiters.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>