<!-- Top Navigation -->
<nav class="navbar">
    <div class="container-fluid">
        <div class="navbar-content">
            <div class="navbar-left">
                <div class="tooltip-custom" data-toggle="tooltip" data-placement="right" title="Toggle Sidebar">
                    <button class="sidebar-toggle" id="sidebarToggle">
                        <i class="bi bi-list"></i>
                    </button>
                </div>
            </div>

            <div class="navbar-right">
                

                <div class="user-dropdown tooltip-custom" data-toggle="tooltip" data-placement="bottom" title="User Menu">
                    <button class="user-dropdown-btn" type="button" data-bs-toggle="dropdown">
                        <div class="user-dropdown-avatar">
                            <?php
                            $name = Auth::user()->name;
                            $nameParts = explode(' ', $name);
                            $initials = '';
                            if (count($nameParts) >= 2) {
                            $initials = strtoupper(substr($nameParts[0], 0, 1) . substr($nameParts[1], 0, 1));
                            } else {
                            $initials = strtoupper(substr($name, 0, 2));
                            }
                            ?>
                            <?php echo e($initials); ?>

                        </div>
                        <span><?php echo e(Auth::user()->name); ?></span>
                        <i class="bi bi-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item">
                                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH /home/techsavy/public_html/listofrecruiters.com/resources/views/admin/layouts/backend/navbar.blade.php ENDPATH**/ ?>