

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <p class="text-muted">Welcome back, <?php echo e(Auth::user()->name); ?>! Here's what's new with your recruiting platform.</p>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-lg-2 col-md-6 mb-4">
        <div class="card stat-card card-hover h-100">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-xs font-weight-bold text-uppercase mb-1">Total Recruiters</div>
                        <div class="h5 mb-0 font-weight-bold"><?php echo e($totalRecruiter ?? ''); ?></div>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="bi bi-people-fill fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-6 mb-4">
        <div class="card stat-card stat-card-success card-hover h-100">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-xs font-weight-bold text-uppercase mb-1">Total Category</div>
                        <div class="h5 mb-0 font-weight-bold"><?php echo e($totalCategroy ?? ''); ?></div>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="bi bi-cart3 fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-6 mb-4">
        <div class="card stat-card stat-card-warning card-hover h-100">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-xs font-weight-bold text-uppercase mb-1">Total Location</div>
                        <div class="h5 mb-0 font-weight-bold"><?php echo e($totalLocation ?? ''); ?></div>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="bi bi-map fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-6 mb-4">
        <div class="card stat-card stat-card-danger card-hover h-100">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-xs font-weight-bold text-uppercase mb-1">Total State</div>
                        <div class="h5 mb-0 font-weight-bold"><?php echo e($totalState ?? ''); ?></div>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="bi bi-map fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-6 mb-4">
        <div class="card stat-card stat-card-info card-hover h-100">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-xs font-weight-bold text-uppercase mb-1">Total City</div>
                        <div class="h5 mb-0 font-weight-bold"><?php echo e($totalCity ?? ''); ?></div>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="bi bi-map fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/techsavy/public_html/listofrecruiters.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>