<img src="{{ asset('img/logo.png') }}" alt="Logo" {{ $attributes }}>
